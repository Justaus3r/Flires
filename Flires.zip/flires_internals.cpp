#include "flires_internals.h"
#include "ticket_creation_internal.h"

FlightBooking::FlightBooking(const char* fName) {
	this->fName = fName;
}

void FlightBooking::createBooking(Booking* bK) {
	this->bK->aircraftName = bK->aircraftName;
	this->bK->aircraftType = bK->aircraftType;
	this->bK->departureDate = bK->departureDate;
	this->bK->destinationCity = bK->destinationCity;
	this->bK->destinationCountry = bK->destinationCountry;
	this->bK->flC = bK->flC;
	this->bK->flightName = this->fName;
}

void FlightBooking::createTicket() {
	;
}

void FlightBooking::compostTicketHtml() {
	;
}

