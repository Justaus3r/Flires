#ifndef FLIRES_INTERNAL_H
#define FLIRES_INTERNAL_H

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>

struct flightCrew {
	//Most Passengers a charter plane can carry are 19
	// Reference: https://compareprivateplanes.com/articles/how-many-passengers-can-a-private-jet-fit
	std::vector<std::string> passengersName;
	std::vector<std::string> passengerGender;
	std::vector<std::string> passengersAge;
    std::vector<std::string> passengerWeightage;
	std::string passengerCount;	

};


struct Booking {
	const char* flightName;
	const char* aircraftType;
	const char* aircraftName;
	flightCrew flC;
	std:: string departureDate;
	std::string destinationCountry;
	std::string destinationCity;
	
};

class FlightBooking {
	public:
		const char* fName;
		Booking* bK;
		FlightBooking(const char* fName);
		void createBooking(Booking *bK);
		void createTicket();
	private:	
		void compostTicketHtml();


};


std::vector<std::string> stringSplit(const std::string& input, char delimiter) {
    std::vector<std::string> tokens;
    std::istringstream tokenStream(input);
    std::string token;

    while (std::getline(tokenStream, token, delimiter)) {
        tokens.push_back(token);
    }

    return tokens;
}

void readTicketData(Booking * bK) {
    system("notepad tmp.ticketinfo.txt");
    std::ifstream fh;
    std::vector<std::string> passengersName;
    std::vector<std::string> passengerGender;
    std::vector<std::string> passengersAge;
    std::vector<std::string> passengerWeightage;

    fh.open("tmp.ticketinfo.txt");

    if (!fh.is_open()) {
        std::cerr << "Error opening ticket file: tmp.ticketinfo.txt" << std::endl;
        exit(0);

    }

    std::string tKLine;

    while (getline(fh, tKLine)) {
        std::vector<std::string> str = stringSplit(tKLine, ' ');
        passengersName.push_back(str[0]);
        passengersAge.push_back(str[1]);
        passengerGender.push_back(str[2]);
        passengerWeightage.push_back(str[3]);
    }

    fh.close();

    bK->flC.passengersName = passengersName;
    bK->flC.passengersAge = passengersAge;
    bK->flC.passengerGender = passengerGender;
    bK->flC.passengerWeightage = passengerWeightage;
}


#endif
